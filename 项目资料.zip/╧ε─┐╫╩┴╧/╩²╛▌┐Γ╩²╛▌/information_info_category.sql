INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-01-17 20:55:48', '2018-04-01 21:45:12', '最新');
INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-01-17 20:55:49', '2018-01-17 20:55:50', '股市');
INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-01-17 20:56:04', '2018-01-17 20:56:06', '债市');
INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-01-17 20:56:18', '2018-01-17 20:56:20', '商品');
INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-01-17 20:56:26', '2018-01-17 20:56:28', '外汇');
INSERT INTO `info_category` (create_time, update_time, name) VALUES ('2018-04-01 21:45:16', '2018-04-01 21:45:16', '公司');